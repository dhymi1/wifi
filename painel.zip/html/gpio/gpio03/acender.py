import RPi.GPIO as GPIO 
import time 
import sys 
import os 
GPIO.setmode(GPIO.BOARD) 
GPIO.setwarnings(False) 
GPIO.setup(40, GPIO.OUT) 
rele_quarto = 40 

def ligar(): 
    GPIO.output(rele_quarto, GPIO.HIGH) 

if __name__ == "__main__": 
    ligar()
